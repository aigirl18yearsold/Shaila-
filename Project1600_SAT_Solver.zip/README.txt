PROJECT--1600 SAT QUESTION SOLVER

Files:
- index.html: complete single-file website.

Run:
1. Open index.html in a modern browser with internet access.
2. Add your Gemini API key in the page.
3. Select PDF files or images, or use the camera button.
4. Choose batch size and press Extract & solve questions.
5. Export a TXT copy or JSON backup of your saved solutions.

Important:
- This is a browser-based personal study tool. The AI call uses Google's Gemini API.
- Google API free-tier availability, model access and quotas can change.
- Never publish your API key in a public GitHub repository or public site.
- The key is not saved by this page. Notebook entries are stored in this browser's localStorage.
- OCR quality depends on image clarity. Diagrams, equations and unusual layouts may be misread; verify uncertain answers.
- A 100-400 question paper may take many batches and can hit free-tier quotas. Completed batches are saved as they finish.
- PDF.js and Tesseract.js are loaded from public CDNs, so internet access is required.
